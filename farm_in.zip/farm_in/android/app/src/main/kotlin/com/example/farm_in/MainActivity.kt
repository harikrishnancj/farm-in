package com.example.farm_in

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
