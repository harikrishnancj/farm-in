const Config= {SERVER:"https://jerihub.cf/farmin"}

export default Config